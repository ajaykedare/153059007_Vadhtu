package in.ac.iitb.cse.a153059007_vadhtu;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import in.ac.iitb.cse.a153059007_vadhtu.adapter.TitleNavigationAdapter;
import in.ac.iitb.cse.a153059007_vadhtu.model.SpinnerNavItem;

public class MainActivity extends AppCompatActivity implements ActionBar.OnNavigationListener{

    // Title navigation Spinner data
    private ArrayList<SpinnerNavItem> navSpinner;

    // Navigation adapter
    private TitleNavigationAdapter adapter;

    // UI references.
    private AutoCompleteTextView mEmailView;
    private AutoCompleteTextView mAgeView;
    private AutoCompleteTextView mMobileNoView;
    private AutoCompleteTextView mFirstnameView;
    private AutoCompleteTextView mLastnameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        ActionBar actionBar = getSupportActionBar();
        actionBar.setLogo(R.drawable.ic_iit_logo_small);
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);

        // Hide the action bar title
        actionBar.setDisplayShowTitleEnabled(false);

        // Enabling Spinner dropdown navigation
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);

        // Spinner title navigation data
        navSpinner = new ArrayList<SpinnerNavItem>();
        navSpinner.add(new SpinnerNavItem("Login", R.drawable.ic_action_person));
        navSpinner.add(new SpinnerNavItem("Sensors", R.drawable.ic_action_network_wifi));

        // title drop down adapter
        adapter = new TitleNavigationAdapter(getApplicationContext(), navSpinner);


        // assigning the spinner navigation
        actionBar.setListNavigationCallbacks(adapter, this);


        //Button signIn_button = (Button)findViewById(R.id.email_sign_in_button)

        mEmailView = (AutoCompleteTextView) findViewById(R.id.email);
        mFirstnameView = (AutoCompleteTextView) findViewById(R.id.firstname);
        mLastnameView= (AutoCompleteTextView) findViewById(R.id.lastname);
        mMobileNoView = (AutoCompleteTextView) findViewById(R.id.phone);
        mAgeView = (AutoCompleteTextView) findViewById(R.id.age);
        Button mEmailSignInButton = (Button) findViewById(R.id.email_sign_in_button);
        mEmailSignInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signInClickFunctionCheck();
            }
        });


    }


    public void signInClickFunction(View v)
    {
        Intent intent = new Intent(getApplicationContext(), SensorsActivity.class);
        startActivity(intent);
    }

    public void signInClickFunctionCheck()
    {

        String email = mEmailView.getText().toString();
        String firstname =  mFirstnameView.getText().toString();
        String lastname=  mLastnameView.getText().toString();
        String mobile=  mMobileNoView.getText().toString();
        String age =  mAgeView.getText().toString();

        mEmailView.setError(null);
        mFirstnameView.setError(null);
        mLastnameView.setError(null);
        mMobileNoView.setError(null);
        mAgeView.setError(null);

        boolean isAllValid = true;
        View focusView = null;

        //Email
        if (TextUtils.isEmpty(email)) {
            mEmailView.setError(getString(R.string.error_field_required));
            focusView = mEmailView;
            isAllValid = false;
        } else if (!isEmailValid(email)) {
            mEmailView.setError(getString(R.string.error_invalid_email));
            focusView = mEmailView;
            isAllValid = false;
        }

        //Firstname
        if (TextUtils.isEmpty(firstname)) {
            mFirstnameView.setError(getString(R.string.error_field_required));
            focusView = mFirstnameView;
            isAllValid = false;
        }

        //LastName
        if (TextUtils.isEmpty(lastname)) {
            mLastnameView.setError(getString(R.string.error_field_required));
            focusView = mLastnameView;
            isAllValid = false;
        }

        //Mobile
        if (TextUtils.isEmpty(mobile)) {
            mMobileNoView.setError(getString(R.string.error_field_required));
            focusView = mMobileNoView;
            isAllValid = false;
        } else if (!isMobileValid(mobile)) {
            mMobileNoView.setError(getString(R.string.error_invalid_mobile));
            focusView = mMobileNoView;
            isAllValid = false;
        }

        //Age
        if (TextUtils.isEmpty(age)) {
            mAgeView.setError(getString(R.string.error_field_required));
            focusView = mAgeView;
            isAllValid = false;
        }


        if (!isAllValid) {
            focusView.requestFocus();
        } else {
            Intent intent = new Intent(getApplicationContext(), SensorsActivity.class);
            startActivity(intent);
        }

    }

    boolean isEmailValid(String e){
        return e.contains("@");
    }

    boolean isMobileValid(String m){
        return m.length()==10;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.menu_main, menu);
        getMenuInflater().inflate(R.menu.activity_main_actions, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }


        switch(id){
            case R.id.action_record:
                LaunchRecordActivity();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }


    }

    /**
     * Actionbar navigation item select listener
     * */
    @Override
    public boolean onNavigationItemSelected(int itemPosition, long itemId) {
        // Action to be taken after selecting a spinner item
        //return false;

        switch(itemPosition){
            case 0:
                //Toast.makeText(getApplicationContext(),"Login Screen Selected"+itemPosition, Toast.LENGTH_LONG).show();
                //LaunchLoginActivity();
                break;
            case 1:
                //Toast.makeText(getApplicationContext(),"Sensor Screen Selected", Toast.LENGTH_LONG).show();
                LaunchSensorsActivity();
                break;
            default:
                //Toast.makeText(getApplicationContext(),"Sensor Screen Selected", Toast.LENGTH_LONG).show();
                break;
        }
        return true;
    }

    /**
     * Launching new activity
     * */
    private void LaunchSensorsActivity() {
        Intent i = new Intent(MainActivity.this, SensorsActivity.class);
        startActivity(i);
    }

    /**
     * Launching new activity
     * */
    private void LaunchRecordActivity() {
        Intent i = new Intent(MainActivity.this, RecordActivity.class);
        startActivity(i);
    }

    /**
     * Launching new activity
     * */
    private void LaunchLoginActivity() {
        Intent i = new Intent(MainActivity.this, MainActivity.class);
        startActivity(i);
    }

}
