package in.ac.iitb.cse.a153059007_vadhtu;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import in.ac.iitb.cse.a153059007_vadhtu.adapter.TitleNavigationAdapter;
import in.ac.iitb.cse.a153059007_vadhtu.model.SpinnerNavItem;

/**
 * Created by ajay on 23/1/18.
 */

public class RecordActivity extends AppCompatActivity implements ActionBar.OnNavigationListener {

    // Title navigation Spinner data
    private ArrayList<SpinnerNavItem> navSpinner;

    // Navigation adapter
    private TitleNavigationAdapter adapter;
    //private ArrayList<String> timestamps;
    ArrayList<TextView> timestampTextViewList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);

        // get action bar
        ActionBar actionBar = getSupportActionBar();

        // Enabling Up / Back navigation
        //actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setLogo(R.drawable.ic_iit_logo_small);
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);

        // Hide the action bar title
        actionBar.setDisplayShowTitleEnabled(false);

        // Enabling Spinner dropdown navigation
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);

        // Spinner title navigation data
        navSpinner = new ArrayList<SpinnerNavItem>();
        navSpinner.add(new SpinnerNavItem("Login", R.drawable.ic_action_person));
        navSpinner.add(new SpinnerNavItem("Sensors", R.drawable.ic_action_network_wifi));


        // title drop down adapter
        adapter = new TitleNavigationAdapter(getApplicationContext(), navSpinner);

        actionBar.setSelectedNavigationItem(1);

        // assigning the spinner navigation
        actionBar.setListNavigationCallbacks(adapter, this);

        //Set on-off switch listner

        Switch onOffSwitch = (Switch)  findViewById(R.id.on_off_switch);
        onOffSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm a ");
                Date date = new Date();
                String datestr = dateFormat.format(date);
                System.out.println(dateFormat.format(date));

                if(isChecked){

                } else{

                    LinearLayout ll = (LinearLayout) findViewById(R.id.records_linearlayout);

                    //Create a temporary instance which will be added to the list
                    final TextView sampleTextView = new TextView(getApplicationContext());
                    int cnt = timestampTextViewList.size();
                    cnt++;
                    String ts = "File"+cnt+" :" + datestr;
                    sampleTextView.setText(ts);
                    sampleTextView.setTextSize(20);

                    if(cnt>=6){
                        ll.removeView(timestampTextViewList.get(cnt-6));

                    }
                    timestampTextViewList.add(sampleTextView);
                    ll.addView(sampleTextView);
                    Toast.makeText(getApplicationContext(),"New File Saved!", Toast.LENGTH_SHORT).show();
                }

            }

        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.menu_main, menu);
        getMenuInflater().inflate(R.menu.activity_main_actions, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }


        switch(id){
            case R.id.action_record:
                LaunchRecordActivity();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }


    }

    /**
     * Actionbar navigation item select listener
     * */
    @Override
    public boolean onNavigationItemSelected(int itemPosition, long itemId) {
        // Action to be taken after selecting a spinner item
        //return false;

        switch(itemPosition){
            case 0:
                //Toast.makeText(getApplicationContext(),"Login Screen Selected", Toast.LENGTH_LONG).show();
                //LaunchLoginActivity();
                break;
            case 1:
                //Toast.makeText(getApplicationContext(),"Sensor Screen Selected", Toast.LENGTH_LONG).show();
                LaunchSensorsActivity();
                break;
            default:
                //Toast.makeText(getApplicationContext(),"Sensor Screen Selected", Toast.LENGTH_LONG).show();
                break;
        }
        return true;
    }

    /**
     * Launching new activity
     * */
    private void LaunchSensorsActivity() {
        Intent i = new Intent(RecordActivity.this, SensorsActivity.class);
        startActivity(i);
    }

    /**
     * Launching new activity
     * */
    private void LaunchRecordActivity() {
        Intent i = new Intent(RecordActivity.this, RecordActivity.class);
        startActivity(i);
    }

    /**
     * Launching new activity
     * */
    private void LaunchLoginActivity() {
        Intent i = new Intent(RecordActivity.this, MainActivity.class);
        startActivity(i);
    }
}