package in.ac.iitb.cse.a153059007_vadhtu;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.ArrayList;

import in.ac.iitb.cse.a153059007_vadhtu.adapter.TitleNavigationAdapter;
import in.ac.iitb.cse.a153059007_vadhtu.model.SpinnerNavItem;

/**
 * Created by ajay on 23/1/18.
 */

public class SensorsActivity extends AppCompatActivity implements ActionBar.OnNavigationListener {

    // Title navigation Spinner data
    private ArrayList<SpinnerNavItem> navSpinner;

    // Navigation adapter
    private TitleNavigationAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensors);

        // get action bar
        ActionBar actionBar = getSupportActionBar();

        // Enabling Up / Back navigation
       // actionBar.setDisplayHomeAsUpEnabled(true);

        actionBar.setLogo(R.drawable.ic_iit_logo_small);
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);

        actionBar.setLogo(R.drawable.ic_iit_logo_small);
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);

        // Hide the action bar title
        actionBar.setDisplayShowTitleEnabled(false);

        // Enabling Spinner dropdown navigation
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);

        // Spinner title navigation data
        navSpinner = new ArrayList<SpinnerNavItem>();
        navSpinner.add(new SpinnerNavItem("Login", R.drawable.ic_action_person));
        navSpinner.add(new SpinnerNavItem("Sensors", R.drawable.ic_action_network_wifi));

        // title drop down adapter
        adapter = new TitleNavigationAdapter(getApplicationContext(), navSpinner);

        //actionBar.setSelectedNavigationItem(1);

        // assigning the spinner navigation
        actionBar.setListNavigationCallbacks(adapter, this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.menu_main, menu);
        getMenuInflater().inflate(R.menu.activity_main_actions, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }


        switch(id){
            case R.id.action_record:
                LaunchRecordActivity();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }


    }

    /**
     * Actionbar navigation item select listener
     * */
    @Override
    public boolean onNavigationItemSelected(int itemPosition, long itemId) {
        // Action to be taken after selecting a spinner item
        //return false;

        switch(itemPosition){
            case 0:
                //Toast.makeText(getApplicationContext(),"Login Screen Selected", Toast.LENGTH_LONG).show();
                //LaunchLoginActivity();
                break;
            case 1:
                //Toast.makeText(getApplicationContext(),"Sensor Screen Selected", Toast.LENGTH_LONG).show();
                //LaunchSensorsActivity();
                break;
            default:
                //Toast.makeText(getApplicationContext(),"Default", Toast.LENGTH_LONG).show();
                break;
        }
        return true;
    }

    /**
     * Launching new activity
     * */
    private void LaunchSensorsActivity() {
        Intent i = new Intent(SensorsActivity.this, SensorsActivity.class);
        startActivity(i);
    }

    /**
     * Launching new activity
     * */
    private void LaunchRecordActivity() {
        Intent i = new Intent(SensorsActivity.this, RecordActivity.class);
        startActivity(i);
    }

    /**
     * Launching new activity
     * */
    private void LaunchLoginActivity() {
        Intent i = new Intent(SensorsActivity.this, MainActivity.class);
        startActivity(i);
    }
}
